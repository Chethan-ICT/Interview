package com.example.demo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/* ============================= CHETHAN V =================================
Date :13-05-2023*/
@Controller
@RequestMapping("/")
public class TimeToWords {

	@RequestMapping(value = "/time", method = RequestMethod.GET)
	public void getTime(HttpServletResponse response, HttpServletRequest request) throws Exception {
		String x =request.getParameter("x");
		String TimeinWords = null;
	    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
	    Date date = null;
	    try {
	        date = sdf.parse(x);
	        String d=sdf.format(date);
	        String[] time = d.split ( ":" );
	        int h = Integer.parseInt ( time[0].trim() );
	        int m = Integer.parseInt ( time[1].trim() );
	         String z,w;
	         String words[] = {"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen",
	             "Sixteen","Seventeen","Eighteen","Nineteen","Twenty","Twenty one","Twenty two","Twenty three","Twenty four","Twenty five","Twenty six",
	             "Twenty seven","Twenty eight", "Twenty nine"};
	         if((h>=1 && h<=12)&&(m>=0&&m<=59)) {
	        	 if(m==1 || m==59) {
	        		 z="Minute";
	        	 }
	        	 else
	             {
	                 z="Minutes";
	             }
	             if(h==12)
	             {
	                 w= words[1];
	             }
	             else 
	             {
	                 w= words[h+1];
	             }
	             if(m==0)
	             {
	                 TimeinWords=words[h]+" O' clock";
	             }
	             else if(m==15)
	             {
	            	 TimeinWords="Quarter Past "+words[h];
	             }
	             else if(m==30)
	             {
	            	 TimeinWords="Half Past "+words[h];
	             }
	             else if(m==45)
	             {
	            	 TimeinWords="Quarter to "+w;
	             }
	             else if(m<30) 
	             {
	            	 TimeinWords=words[m]+" "+ z +" past "+words[h];
	             }
	             else 
	             {
	            	 TimeinWords=words[60-m]+" "+ z +" to "+w;
	             }
	         }
	         else
	         {
	             System.out.println("Invalid Time Entered"); 
	         } 
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
	

	    response.getWriter().print(TimeinWords);
}
	
	@RequestMapping(value = "/daysegment", method = RequestMethod.GET)
	public void getDaySegment(HttpServletResponse response, HttpServletRequest request) throws Exception {
		String Daytime =request.getParameter("Daytime");
		String TimeinWords = null;
		String[] timing = Daytime.split ( ":" );
		int h = Integer.parseInt ( timing[0].trim() );
        int m = Integer.parseInt ( timing[1].trim() );
      try {  
       if(h==00 && m==00) {
    	   TimeinWords="Its Mid-Night";
       }else if (h==12 && m==00) {
    	   TimeinWords="Its Mid-Day";
       }else if (h<=11 && h>=00) {
    	   TimeinWords="Its Morning";
       }else if (h>=12 && h<16) {
    	   TimeinWords="Its Afternoon";
       }else if (h>=16 && h<19) {
    	   TimeinWords="Its Evening";
       }else if (h>=19 && h<=23) {
    	   TimeinWords="Its Night";
       }
      }catch (Exception e) {
	        e.printStackTrace();
	    }
      
	    response.getWriter().print(TimeinWords);
}
}
